total = 0 #변수 초기화
for a in range(1, 11, 1): # 1부터 10까지 1씩 증가 반복
    total += a # 합계 구하는 식
    print(a, total)
print("1부터 10까지 합:", total)
