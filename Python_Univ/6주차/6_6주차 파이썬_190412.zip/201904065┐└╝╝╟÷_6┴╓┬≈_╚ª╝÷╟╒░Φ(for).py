#21 - 30까지의 홀수 합계
total = 0
for t in range(21, 31, 2):
    total += t
print("21 부터 30까지의 합:", total)
    
