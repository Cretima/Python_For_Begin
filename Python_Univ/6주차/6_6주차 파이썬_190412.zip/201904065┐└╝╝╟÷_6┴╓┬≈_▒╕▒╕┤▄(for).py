num1 = int(input("몇단을 할까요? : "))

for a in range(1, 10, 1 ):
    print(num1, "*", a, "=", num1 * a) 
