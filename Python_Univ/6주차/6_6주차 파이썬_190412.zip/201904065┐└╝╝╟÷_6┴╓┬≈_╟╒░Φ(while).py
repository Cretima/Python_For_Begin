total = 0  #변수 초기화
a = 1 # 반복할 변수 a를 1로 초기화
while a <= 10 :
    total += a #합계 구하는 식
    print(a, total)
    a += 1
print("1부터 10까지 합:", total)
