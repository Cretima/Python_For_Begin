for j in range(2, 10, 1 ):
    for i in range(1, 10, 1):
        print(j, "*", i, "=", j * i) 
